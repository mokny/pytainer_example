import requests
import time
# Required imports for pyTainer
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.resolve()) + '/../../ipc')
import pytaineripc

# Your code here - All below is optional

def pytainerNotificationHandler(data):
   print("Notification received:" + str(data))

def pytainerEventHandler(data):
   print("Event received:" + str(data))

# Initialize the IPC interface to receive notifications and events
pytaineripc.init(__file__, pytainerNotificationHandler, False)

# Get the config from the UI
config = pytaineripc.getConfig()

print("pyTainer Default Standalone Template. Edit /home/pi/pytainer/repos/dudai/init.py to code your own app.")

while True:
	print("Fetching the weather for airport " + config['icao'])
	url = 'https://tgftp.nws.noaa.gov/data/observations/metar/decoded/'+config['icao']+'.TXT'
	r = requests.get(url,timeout=(5,5))
	pytaineripc.raiseEvent('WeatherData', r.text)
	print("Done. Waiting for " + str(config['interval']) + ' minutes...')
	time.sleep(config['interval'] * 60)
 
print("Done!")